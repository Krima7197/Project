

import UIKit
import JVFloatLabeledTextField
import HTPressableButton

class ViewController: UIViewController {

    let  REGEX_USER_NAME_LIMIT = "^.{3,10}$";
    let REGEX_USER_NAME = "[A-Za-z]{3,10}";
    let  REGEX_EMAIL = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    let REGEX_PASSWORD_LIMIT = "^.{6,20}$";
    let REGEX_PASSWORD = "[A-Za-z0-9]{6,20}";
    let REGEX_PHONE_DEFAULT = "[0-9]{10}";

    @IBOutlet weak var txtUname: UITextField!
    @IBOutlet weak var txtMno: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    @IBOutlet weak var txtCpass: UITextField!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
    }
    
    func setvalidation()
    {
        txtUname.addRegx(REGEX_USER_NAME, withMsg: "Please enter username")
        txtUname.presentInView = self.view
        txtPass.addRegx(REGEX_PASSWORD, withMsg: "Please enter password")
        txtPass.presentInView = self.view
        txtMno.addRegx(REGEX_PHONE_DEFAULT, withMsg: "Enter Mobile No.")
        txtMno.presentInView = self.view
    }
    
    @IBAction func btnRegister(_ sender: Any)
    {
        
    }
    
    func validate1() -> Bool
    {
        if txtUname.validate() && txtPass.validate() && txtMno.validate()
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    @IBAction func btnaction(_ sender: Any)
    {
        if validate1()
        {
            print("Done")
        }
        else
        {
            print("Record Invalid")
        }
    }

    
    @IBAction func btnReset(_ sender: Any)
    {
        txtUname.text = ""
        txtMno.text = ""
        txtPass.text = ""
        txtCpass.text = ""
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }


}

