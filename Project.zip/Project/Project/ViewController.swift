
import UIKit
import SkyFloatingLabelTextField

class ViewController: UIViewController
{

    override func viewDidLoad()
    {   let txt = SkyFloatingLabelTextField(frame: CGRect(x: 20, y: 20, width: 200, height: 30))
        txt.placeholder = "name"
        txt.title = "your name"
        self.view.addSubview(txt)
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }


}

