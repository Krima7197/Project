
import UIKit

class login: UIViewController
{
     @IBOutlet weak var btnLogin: UIButton!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        
    }

    
    
   
    
    @IBAction func LoginAction(_ sender: Any)
    {   
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    

 

}
